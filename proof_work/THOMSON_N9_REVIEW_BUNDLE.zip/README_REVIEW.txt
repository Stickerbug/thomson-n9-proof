Thomson n=9 proof candidate -- review bundle (regenerated)
===========================================================

SCOPE.  This package records a locally closed computer-assisted proof chain for
the frozen statement described in THOMSON_N9_PROOF_CANDIDATE_zh.md.  It is a
proof CANDIDATE: it has not been externally peer reviewed, the nine-point
energy theorem has not been formally verified, and no statement about the
global uniqueness of the minimizer is made.

START HERE
  1. proof_work/THOMSON_N9_PROOF_CANDIDATE_zh.md   (frozen statement + proof)
  2. proof_work/THOMSON_N9_CURRENT_zh.md           (full technical record)
  3. proof_work/publication_validation/VALIDATION_STATUS_zh.md
                                                   (what has been verified)
  4. proof_work/publication_validation/README_independent_checker.md
  5. proof_work/publication_validation/SUBMISSION_MANUSCRIPT_en.md
  6. proof_work/publication_validation/SUBMISSION_CHECKLIST_zh.md

REQUIREMENTS.  Python 3, numpy, sympy; a little-endian 64-bit machine and GCC
with signed __int128 for the historical shared objects.  The independent
checker itself is pure Python stdlib.

(T1) INDEPENDENT EXACT ARITHMETIC CHECK (fresh recomputation of the whole tree)
  python3 -u proof_work/publication_validation/test_checker_exact.py
  python3 -u proof_work/publication_validation/checker_exact.py \
    --inputs proof_work/publication_validation/sharp_root_inputs.json \
    --tree proof_work/publication_validation/sharp_root_tree.jsonl \
    --output proof_work/publication_validation/independent_full_result.json \
    --expected-input-sha256 3dd4ba639e78cabaa2c3a8182db3724545751ade50635e6d542067338b281066
  Recorded sharded replay: proof_work/publication_validation/sharded_run_v1/
  (154 shards, 136125 nodes, 68063 leaves, pending=0).

(T2) NEGATIVE / FAILURE-PROPAGATION TESTS
  python3 -u proof_work/publication_validation/test_checker_exact.py
  python3 -u proof_work/publication_validation/test_checker_supplemental.py

(T3) HISTORICAL FULL REPLAY (same implementation, not an independent kernel)
  OPENBLAS_NUM_THREADS=1 python3 proof_work/verify_thomson_n9_sharp.py \
    --outdir proof_work/new_external_replay

(T4) LEAN 4 SOURCES (partial formalization; final theorem NOT formalized)
  proof_work/publication_validation/formal/README_build.md explains the pinned
  Lean 4.34.1 / Mathlib d13f23b7 toolchain.  The modules Statement, Family,
  CandidateMem, DomainCoverage, LeafSemantics, Derivative, Stationary,
  SecondDerivative, Minimum, StrictConvex, EnergyContinuity, Applications and
  ContactInner compile; the axiom audit and the coverage lemmas are included.
  Applications.lean proves isometry invariance, the inner-product form of the
  energy and a crude unconditional lower bound; ContactInner.lean computes the
  six candidate-family inner products A, B, C, D, F, G.  Stationary.lean formalizes the endpoint signs, continuity and the
  existence of the family stationary point; SecondDerivative.lean formalizes
  positivity of the second derivative and Rolle-theorem uniqueness
  (exists_unique_stationary_point); Minimum.lean formalizes strict monotonicity
  of the derivative and the unique strict global minimum of the family energy
  (exists_unique_familyEnergy_min); EnergyPath.lean proves the multi-point path
  derivative, GradientZero.lean the equivalence of vanishing gradient and
  stationarity, EnergyOptimality.lean first-order optimality, EnergySymmetry.lean
  relabeling invariance, and Minimizer.lean the existence of a global minimizer
  (exists_global_minimizer, exists_global_minimizer_lt_26).  ThreePoint.lean is
  an attributed adaptation of the Bachoc-Vallentin three-point positivity from
  the N=7 Lean project (quad_Y3_nonneg, bv_positivity); its general-PSD pairing
  lemma is explicitly deferred.  ThreePointBound.lean ports the reduced-kernel
  combinatorics (dsum, Rs, dsum_Rs, dsum_H, Rk, sum4_swap) and the exact
  three_point_identity from the same project; three_point_bound still awaits the
  PSD moment inequality matDot_moment_nonneg.  FinalAssembly.lean proves the frozen claim is
  equivalent to the global lower bound (thomsonNineClaim_iff_global_lower_bound);
  the unformalized part is exactly that bound.  DomainChamber.lean sorts any
  physical inner-product triple into the ordered chamber with the Gram constraint
  preserved.  There is no Lean proof of the nine-point energy
  statement, and `sorry`/`axiom` are absent from the sources. The independent
  `verify_aaa_shift_binding.py` replays the formal three-axis interval
  algorithm exactly and checks 807/807 archived shifted-coefficient targets.
  `TwoSourceBindings.lean` and `ChainBindings.lean` prove 32 two-source plus
  54 three/four-source target interval bounds (together with TargetBinding
  .t126, 87 of the 807 targets), and `MultiCornerBindings.lean` adds 15
  five-source multi-axis delta≤1 targets and `MultiCornerPowBindings.lean` adds 9
  delta≥2 five-source multi-axis targets, `MultiCornerPBindings.lean` adds 13
  eight-source multi-axis targets whose per-source intervals are contained; for 254 of the 807 targets; these are
  interval arithmetic certificates.  `GatheredBinding.lean` additionally
  proves that the full 807-term gathered coefficient for `.t126` equals its two
  contributing binomial terms and lies in the archived interval.

(T5) LEAN LOCAL CERTIFICATE (conditional; NOT the global theorem)
  The 12-class LDL replay and the AAA H00 sparse Hessian certificate are
  compiled and checked by the unified local verifier:
  python3 -B proof_work/publication_validation/verify_local_lean.py --adopt-build
  Recorded result (2026-10-20 14:08 UTC): status
  LOCAL_LEAN_COMPILER_AXIOMS_AND_KERNEL_PASS, 644 #print axioms directives,
  90-module closure, and leanchecker ThomsonNine.LocalVerification exit 0.
  See proof_work/publication_validation/local_lean_verification.json and
  local_lean_build_stamp.json.  The AAA theorem assumes a fixed real
  coefficient family in coefficientInterval and a point in relativeBox; its
  binding to the true residual/shifted coefficients is NOT proved.  Other
  classes, the 45 contact equations, the 68,063-leaf coverage instantiation,
  and the final ThomsonNineClaim remain unformalized.  This is a local,
  conditional certificate, not an external review or a solution of the
  nine-point problem.

CAVEATS.  The manuscript-style links in THOMSON_N9_CURRENT_zh.md use original
absolute paths; open the corresponding extracted files instead.  The full
replay uses the same implementation, not an independent proof checker.  Files
were hashed at packing time; see proof_work/SHARP_N9_REVIEW_MANIFEST.json.

Generated 2026-10-21 00:57 UTC.
