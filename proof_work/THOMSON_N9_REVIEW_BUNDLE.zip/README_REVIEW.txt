Thomson n=9 -- frozen global theorem, Lean proof and review sources
==================================================================

The exact, unchanged ThomsonNineClaim is proved by
  ThomsonNine.thomsonNineClaim_proved : ThomsonNine.ThomsonNineClaim

The theorem states that the specified three-ring candidate at the unique
stationary radius r in (0,1) lies on the unit sphere, has the stated energy,
and has energy no greater than every injective nine-point sphere configuration.
It does not state that all minimizing configurations are congruent.

START HERE
  proof_work/publication_validation/GLOBAL_THEOREM_2026-10-22_zh.md
  proof_work/publication_validation/formal/ThomsonNine/Statement.lean
  proof_work/publication_validation/formal/MainCoverage/Final.lean
  proof_work/publication_validation/local_lean_verification.json
  proof_work/publication_validation/README_local_lean.md

VERIFICATION
  LOCAL_LEAN_COMPILER_AXIOMS_AND_KERNEL_PASS
  2390 modules in the complete import closure.
  1507 distinct, ordered axiom audits.
  Only propext, Classical.choice and Quot.sound are allowed; no sorryAx.
  All 807 archived coefficient targets and all 12 actual local neighborhoods
  are connected to the actual residual. The archived 136125-node tree has
  68063 leaves and is checked through 498 certified frontier subtrees.
  Complete replay: leanchecker --fresh ThomsonNine.LocalVerification
  The formal root and final theorem are contained in that replay closure.
  Original module names and exact existing compiler artifacts were explicitly
  adopted, then the entire imported proof was replayed in a fresh kernel.

Lean 4.34.1 and Mathlib d13f23b723b8a846827a245b89c10fc7d3f11612 are pinned.
leanchecker uses Lean's own kernel. This is not an external independent
implementation or peer review. Earlier Python exact-arithmetic evidence is
included with its original scope; it is not a substitute for that distinction.

REPRODUCE
  Set LEAN_BIN_DIR to the pinned Lean bin directory, preserve formal/.lake,
  then run python3 -B proof_work/publication_validation/verify_local_lean.py
  A prior matching PASS stamp permits --reuse-local-build. --adopt-build
  explicitly adopts existing artifacts with source/artifact hash checks.
  The verifier discovers owned modules through packed_coverage_manifest.json,
  checks source templates and input hashes, rejects unregistered local imports,
  audits all declared conclusions, and runs one complete fresh kernel replay.
  After PASS: python3 proof_work/publication_validation/build_review_bundle.py

The earlier ThomsonNine/Construction copies remain as historical reproducibility
sources. They are superseded by the original-name modules and are not imported
alongside them. Exact current import counts are in local_lean_expected.json.
Progress documents dated before the final theorem describe historical stages.

INTEGRITY
  proof_work/SHARP_N9_REVIEW_MANIFEST.json hashes every payload file.
  Compiled caches and toolchain binaries are excluded from this source archive.
  Generated 2026-10-24T11:05:18.379134+00:00 UTC.
