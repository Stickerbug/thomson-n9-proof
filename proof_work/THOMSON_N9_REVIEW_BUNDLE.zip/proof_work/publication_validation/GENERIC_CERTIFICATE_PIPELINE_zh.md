# 面向任意实例的证书流水线（阶段 A，2026-10-24）

## 目标

目标是提供一个“输入实例编号、搜索并验证证书”的半自动流水线。对给定的 `n`，外部程序可以寻找候选构型和精确证书；Lean 只接受通过通用检查器的证书。成功运行输出正式定理，失败运行输出 `unknown` 或生成失败记录。

这一区分很重要：证书检查器可以是通用的，但目前没有定理保证任意 `n` 都存在可搜索到的候选构型、低维约化或有限覆盖证书。因此当前目标是“找到就证明”，不是声称已经有任意 `n` 的完备自动求解器。

## Lean 内核接口

`ThomsonCertificate.Certificate n` 和 `ThomsonCertificate.CertificateFamily` 位于
`formal/ThomsonCertificate/GenericCertificate.lean`，包含：

`CertificateFamily` 则按 `n` 提供一族这样的对象，并有 `CertificateFamily.sound`。

`GenericLowerBound.lean` 的 `LowerBoundBridge.sound` 再把证书目标连接回原始配置的能量下界；配置空间、约化映射和能量恒等式仍由每个 n 的 adapter 提供。

- 实例专用的盒类型和点类型；
- `Spec`：域、目标、叶证书和分裂关系；
- 有限覆盖树；
- `Checked` 证明。

核心定理是：

```lean
ThomsonCertificate.Certificate.sound
```

它把 `Checked` 证书转换成整个覆盖域上的目标命题。Bernstein、PSD 和覆盖树模块都可以作为实例适配器的组成部分。

## 外部生成器和可信边界

建议的运行阶段如下：

1. `discover(n)`：数值搜索候选构型、对称性和低维参数；
2. `exactify(n, candidate)`：求解接触方程，生成有理数或代数数数据；
3. `certify(n, exact_data)`：生成 PSD 块、局部区间证书、Bernstein 系数和覆盖树；
4. `export(n, certificate)`：输出 JSON 数据和生成的 Lean 适配器；
5. `check(n, adapter)`：编译并运行 Lean 内核检查器；
6. 只有第 5 步成功，流水线才报告 `proved`。

搜索、数值优化和证书生成器属于不可信输入；它们可以出错，但错误必须在 Lean 检查阶段被拒绝。外部生成器不应把浮点结果直接当成定理前提。

## 可执行调度器

`run_certificate_pipeline.py` 读取 `schema = thomson-certificate-v1` 的清单，拒绝路径穿越和缺失源文件，然后调用 `lake env lean` 编译指定 adapter。n=9 清单 `certificate_manifests/n9_structured.json` 已运行通过，记录为 `status = PASS`；一个含 `../` 路径的负向清单返回 `UNKNOWN`。该脚本只负责证书验证调度，尚未实现候选构型搜索。

n=10 清单 `certificate_manifests/n10_candidate_only.json` 明确使用 `candidate_only` 模式并返回 `UNKNOWN`。其中的旧 `analytic10` 证据是 n=9 的十阶多项式实验，不是十粒子全局证书。当前已经有真正的 n=10 D4d 几何和能量模型，以及候选区间的 Lean 层；但尚无覆盖整个十点构型空间的 certificate adapter。

`certificate_manifests/n10_discovery.json` 使用 `discovery` 模式记录真实十粒子候选的接入门槛，并返回 `UNKNOWN`。具体字段、阶段门和后续工作见 `N10_DISCOVERY_INTAKE_2026-10-24_zh.md`；旧的 `analytic10`/`d10` 文件仍只作为 n=9 十阶核实验保留。
本轮另有固定种子的 32 次 L-BFGS-B 数值提案（能量约 `32.71694946014815`），仅用于候选发现，尚未进入证明管线。 其对称性拟合和一参数能量公式记录在 `n10_d4d_symmetric_family_2026-10-24.json`，仍属于 discovery。`ThomsonCertificate/N10D4dGeometry.lean` 已由 Lean 验证 D4d 十点构型的单位球面、两两不同和 45 项能量恒等式。 驻点消元记录在 `n10_stationarity_elimination_2026-10-24.json`，只提供必要的 224 次结果式因子。 之后的 `n10_root_isolation_2026-10-24.json` 用有理 Bernstein 导数系数证明该区间内结果式根唯一，并用纯有理区间算术确认原始含根号驻点表达式在区间端点变号，同时给出 D4d 族能量的严格区间包围；`ThomsonCertificate/N10CandidateInterval.lean` 由 Lean 验证 `t` 到 `h` 的有理区间映射、驻点表达式的区间连续性和 IVT 零点桥接。当前缺口是把端点符号证书重放进 Lean，以及建立整个十点构型空间的全局下界；因此这些材料仍不能把 discovery 状态提升为 `proved`。

独立文件 `n10_stationarity_endpoint_certificate_2026-10-25.json` 记录两个端点的完整有理区间运算链和严格符号，供后续 Lean 重放逐项对照。

另有 `n10_rational_lp_bound_2026-10-25.py/json` 以纯 `Fraction` 和 Bernstein 细分给出外部无条件基线 `E10 >= 326807/10000 = 32.6807`；它低于 D4d 候选约 `32.71694946`，没有改变 n=10 的 `UNKNOWN` 状态，也尚未由 Lean 重放。`N10StationarityEndpoint.lean` 已编译通过区间原语层，但不等于最终驻点端点符号定理。

n=9 清单 `certificate_manifests/n9_global_claim.json` 进一步编译 `GlobalMinimumContract` 适配器，统一暴露候选可行性、候选能量恒等式和全局下界；它运行结果为 `PASS`，但仍复用现有冻结 n=9 定理，不改变根入口。

`GenericUniqueness.lean` 提供可选的 `EqualityClassification` 层。n=7/n=8 的等号唯一性可以填充该层；n=9 当前合同不填充它，因此不会产生未经证明的唯一性声明。

n=7 和 n=8 的 `external_claim_only` 清单只记录外部仓库的声明、提交和许可证状态，调度器返回 `UNKNOWN`，直到源代码获准并在本项目中完成 adapter 和重放。

## 建议的证书数据分层

```text
candidate.json       候选构型和参数的精确表示
model.json           Thomson 能量到低维残差的约化数据
contact.json         接触方程、秩和兼容性证书
psd_blocks.json      PSD 块及其精确 LDL/合同数据
local.json           局部 Hessian、边界和 Hermite 证书
tree.json            Bernstein 覆盖树和叶终止原因
generated/Instance.lean 由上述数据生成的 Lean 适配器
```

## 可验证的阶段目标

1. 用 `Certificate 9` 包装现有 n=9 覆盖证明，不改变冻结定理（语义和结构化 `CutTree` 适配器均已通过）；
2. 选取 n=7 或 n=8 建立第二个适配器，报告真正复用的模块和许可证；
3. 将证书生成器从 n=9 的固定脚本抽象为参数化导出器；
4. 用相同接口对 n=10 完成端点重放、候选适配器和小规模证书试验；
5. 将 n=9 的 PSD/局部/覆盖结构参数化到十点实例，生成并审计全局下界证书；
6. 只有完成完整模型约化、覆盖和审计后，才报告 n=10 的正式证明。

当前 `GenericCertificate`、`GenericBernstein`、`GenericCoverage`、`GenericPSD` 和 `GenericFramework` 已构成阶段 A 的 Lean 原型；n=9 适配器和外部证书生成器仍是后续工作。
