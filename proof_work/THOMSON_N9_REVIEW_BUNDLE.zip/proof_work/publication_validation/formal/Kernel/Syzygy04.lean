import Kernel.SyzygyData
set_option maxRecDepth 100000
set_option maxHeartbeats 1000000000
noncomputable section
namespace ThomsonNine.ActualKernel.Syzygy
theorem p_zero_04 : ∀ i : Fin 11, dotNum p 4 i=[] := by decide +kernel
theorem c_zero_04 : ∀ i : Fin 11, dotNum c 4 i=[] := by decide +kernel
end ThomsonNine.ActualKernel.Syzygy
